<?php

/**
 * @var \App\View\AppView $this
 * @var \Cake\Datasource\EntityInterface[]|\Cake\Collection\CollectionInterface $users
 */
?>

<div class="users index content">
    <?= $this->Html->link(__('New Article'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Articles') ?></h3>

    <!-- <?= $this->Form->create(null, ['type' => 'get']) ?>
    <?= $this->Form->control('key', ['label' => 'Search', 'value' => $this->request->getQuery('key'), 'autocomplete' => 'off']) ?>
    <?= $this->Form->submit() ?>
    <?= $this->Form->end() ?> -->

    <div class="table-responsive">
        <!-- <?= $this->Form->create(null, ['url' => ['action' => 'deleteAll']]) ?>
        <button>Delete All</button> -->
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th><?= $this->Paginator->sort('Title') ?></th>
                    <th><?= $this->Paginator->sort('Body') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>

            <tbody>
                <?php foreach ($users as $user) : ?>
                    <tr>
                        <td><?= $this->Number->format($user['id']) ?></td>
                        <td><?= h($user['title']) ?></td>
                        <td><?= h($user['body']) ?></td>
                        <td class="actions">
                            <?= $this->Html->link(__('Like'), ['action' => 'like', $user['id']]) ?>
                            <?= $this->Html->link(__('View'), ['action' => 'view', $user['id']]) ?>
                            <?= $this->Html->link(__('Edit'), ['action' => 'edit', $user['id']]) ?>
                            <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $user['id']], ['block' => true, 'confirm' => __('Are you sure you want to delete # {0}?', $user['id'])]) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>

        </table>
        <?= $this->Form->end() ?>
        <?= $this->fetch('postLink'); ?>
    </div>
    
</div>