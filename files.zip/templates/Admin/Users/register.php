<?= $this->Form->create() ?>
<?= $this->Form->control('username'); ?>
<?= $this->Form->control('email'); ?>
<?= $this->Form->control('amount'); ?>
<?= $this->Form->control('status'); ?>
<?= $this->Form->control('password'); ?>
<?= $this->Form->submit() ?>
<?= $this->Form->end() ?>
