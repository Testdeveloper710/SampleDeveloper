<?php 

// src/Model/Table/LikeTable.php

namespace App\Model\Table;

use Cake\ORM\Table;

class LikesTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        // Set the table name
        $this->setTable('likes');

        // Define the table schema
        $this->addBehavior('Timestamp'); // Automatically populate `created` and `modified` fields

        // Define table columns
        // $this->addColumn('user_id', ['type' => 'integer']);
        // $this->addColumn('article_id', ['type' => 'integer']);

        // Define associations
        $this->belongsTo('Users');
        $this->belongsTo('Articles');
    }
}

?>