<?php
declare(strict_types=1);

namespace App\Controller\Admin;
use \SplFileObject;
use App\Controller\Admin\AppController;
use Cake\Datasource\ConnectionManager;
// use Cake\Auth\DefaultPasswordHasher;
/**
 * Users Controller
 *
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{
    public function login()
    {
        if($this->request->is('post')){
            $user = $this->Auth->identify();
            
            if($user){
                $this->Auth->setUser($user);
                
                if($user['status'] == 0)
                {
                    $this->Flash->error("You have not access permission !");
                    return $this->redirect(['controller' => 'Users', 'action' => 'logout']);
                }

                return $this->redirect(['controller'=>'Users','action'=>'index']);
            }else {
               // $pwd = (new DefaultPasswordHasher)->hash("123456");
                //print_r($pwd);
                $this->Flash->error("Incorrect username or password !");
            }
        }
    }

    public function logout(){
        return $this->redirect($this->Auth->logout());
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $connection = ConnectionManager::get('default');
        // debug($connection);
        $statement = $connection->execute('SELECT count(*) as count from articles');
        // $statement->execute();
        $userCount = $statement->fetch('assoc');
        // var_dump($userCount["count"]);
        // exit;
        $key = $this->request->getQuery('key');
        $query = $connection->newQuery();
        $query->select('*')->from('articles');
        if($key){
            $query->where(['title LIKE' => '%' . $key . '%']);
        }

        $users = $query->execute()->fetchAll('assoc');
        // $users = $this->paginate($query,['contain'=>['Profiles', 'Skills']]);
        $users = $query;
        
        $this->set(compact('users', 'userCount'));
    }

    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->loadModel('Articles');
        $article = $this->Articles->get($id, [
            'contain' => [],
        ]);

        $this->set('article', $article);
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */

    public function delete($id = null)
    {
        $this->loadModel('Articles');
        $this->request->allowMethod(['post', 'delete']);
        $article = $this->Articles->get($id);
        
        if ($this->Articles->delete($article)) {
            $this->Flash->success(__('The article has been deleted.'));
        } else {
            $this->Flash->error(__('The article could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function register()
    {
        $user = $this->Users->newEmptyEntity();
        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The User has been saved.'));

                return $this->redirect(['action' => 'login']);
            }
            $this->Flash->error(__('The User could not be saved. Please, try again.'));
        }
       // $this->set(compact('student'));
    }

    public function like($articleId)
    {
        $this->loadModel('Likes');
        // Check if the user is logged in
        if (!$this->Auth->user()) {
            $this->Flash->error(__('You need to login to like an article.'));
            return $this->redirect($this->referer());
        }

        $existingLike = $this->Likes->find()
        ->where(['user_id' => $this->Auth->user('id'), 'article_id' => $articleId])
        ->first();

        if ($existingLike) {
            $this->Flash->error(__('You have already liked this article.'));
            return $this->redirect($this->referer());
        }
        
        // Save the like
        $likeData = [
            'user_id' => $this->Auth->user('id'),
            'article_id' => $articleId
        ];
        $like = $this->Likes->newEntity($likeData);
        
        $save = $this->Likes->save($like);
        //print_r($save);exit;
        if ($this->Likes->save($like)) {
            $this->Flash->success(__('Article liked successfully.'));
        } else {
            $this->Flash->error(__('Failed to like the article.'));
        }
        return $this->redirect($this->referer());
    }

    public function add()
    {
        $this->loadModel('Articles');
        // Check if the user is logged in
        if (!$this->Auth->user()) {
            $this->Flash->error(__('You need to login to add an article.'));
            return $this->redirect($this->referer());
        }
        
        if ($this->request->is('post')) {
            $articleData = [
                'title' => $this->request->getData('Title'),
                'body' =>  $this->request->getData('Body'),
                'user_id' => $this->Auth->user('id')
            ];

            $article = $this->Articles->newEntity($articleData);
            if ($this->Articles->save($article)) {
                $this->Flash->success(__('The Article has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The Article could not be saved. Please, try again.'));
        }
       
    }

    public function edit($id = null)
    {
        $this->loadModel('Articles');
        // Check if the user is logged in
        if (!$this->Auth->user()) {
            $this->Flash->error(__('You need to login to add an article.'));
            return $this->redirect($this->referer());
        }

        $article = $this->Articles->get($id);

        if ($this->request->is(['patch', 'post', 'put'])) {
            $article = $this->Articles->patchEntity($article, $this->request->getData());

            if ($this->Articles->save($article)) {
                $this->Flash->success(__('The article has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The article could not be saved. Please, try again.'));
        }
        $this->set(compact('article'));
    }
}
